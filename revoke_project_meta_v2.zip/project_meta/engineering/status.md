# Engineering Status

Last canonical update: 2026-09-04

Source baseline: `../audits/2026-09-04-revival-audit.md`.

This file answers **what exists now**, not what v2 intends to build.

## Current healthy foundations

### Confirmed working / salvageable

- Flutter application shell and Firebase initialization in normal app launch;
- Google/Firebase authentication and user bootstrap;
- installed-app discovery;
- whitelist;
- Time Block schedules;
- Usage Limit schedules;
- local-first schedule cache;
- native schedule synchronization path;
- Accessibility foreground event path;
- UsageStats fallback/backstop;
- native hard blocker overlay;
- usage-limit soft/interstitial reminders;
- native temporary unlock persistence;
- boot/alarm/watchdog scaffolding;
- local UsageStats Insights;
- Squad creation/join;
- Plea creation;
- Tribunal chat/voting;
- server-authoritative Plea/vote/message writes;
- AI fallback and sanitization/parser tests;
- rap sheet/server blocked-attempt ingestion;
- Firestore rules tests;
- Android Kotlin debug compilation;
- Flutter static analysis.

## Current broken or release-blocking behavior

- onboarding can skip/resume incorrectly;
- vow/goal is not persisted;
- stale Flutter widget smoke test fails due Firebase-less startup and obsolete counter expectation;
- Launch Count is not enforced;
- approved Plea → native unlock depends on a live/restarted Flutter listener;
- taper plans are not integrated into onboarding and are not fully remotely hydrated;
- schedule synchronization has no revision/conflict protocol;
- usage budget source and foreground event source differ without confidence semantics;
- time/day/timezone boundaries are not formally reconciled;
- device/OEM Accessibility recovery is not proven by integration/device tests.

## Product concepts currently present but not v2-ready

- Focus Score: implemented/visible but scheduled for retirement from v2 UX.
- Squads: functional but product model will evolve to Accountability Circles.
- Pleas/Tribunals: functional core but need durable delivery, fixed voter policy, and idempotency hardening.
- Taper: implemented as Home opt-in but will become core Commitment behavior.
- Admin/God Mode: exists; production surface must be deliberately gated.

## Not implemented in current repo

- Revoke 2.0 Commitment domain object;
- granular Accountability Circle permissions;
- v2 onboarding state machine;
- subscription/paywall entitlement flow;
- financial Commitment Stakes;
- financial verification state machine;
- server-authoritative commitment billing;
- Danger Zone behavioral analysis;
- v2 adherence/recovery cards;
- Social Regimes/community marketplace;
- category analytics;
- complete Launch Count enforcement.

## Revival order

Recommended dependency order:

1. repair deterministic onboarding and goal persistence;
2. replace stale test bootstrap and keep all existing test suites green;
3. prove enforcement/recovery on physical/emulated devices;
4. introduce Commitment domain layer over existing schedules;
5. add schedule revisions/native acknowledgments/conflict policy;
6. formalize usage evidence, timezone, and verification health;
7. make override approval delivery durable without Flutter dependency;
8. migrate Squad product semantics toward Circle permissions;
9. implement subscription entitlement/paywall;
10. implement financial Stake domain only after verification and policy gates are satisfied;
11. replace Focus Score UI with direct adherence/override/recovery cards;
12. expand advanced insights later.

## Rule

Do not mark a v2 feature "implemented" in product docs because a model, screen, or placeholder exists. Update this status only after an end-to-end executable path is verified.
