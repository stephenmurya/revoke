# Implementation Principles

## 1. Revive, do not rebuild by default

The September 2026 audit found the core architecture salvageable. Rewrite only when a specific correctness, security, or maintainability constraint cannot be solved safely in place.

## 2. Preserve native enforcement assets

Treat the current Android enforcement stack as valuable infrastructure:

- Accessibility fast path;
- UsageStats fallback;
- EnforcementEngine;
- RevokeConfig persistence;
- native overlays;
- temporary unlocks;
- boot/alarm/watchdog recovery.

## 3. Add a v2 domain layer over existing schedule primitives

Do not force native Android to understand every product concept immediately.

A Commitment may materialize existing `timeBlock` and `usageLimit` rules while v2 Flutter/backend state owns the higher-level contract.

## 4. Make authority explicit

For every important field define one authority:

- device-native;
- Flutter/local;
- Firestore client-owned;
- server-owned;
- payment processor-owned.

Avoid fields that can be independently and silently rewritten by multiple layers.

## 5. Financial state is server-owned

Native/Flutter may supply evidence. They never finalize a charge.

The backend must independently validate immutable terms, telemetry sufficiency, grace state, idempotency, and processor response.

## 6. Unknown is a real state

Do not coerce missing telemetry into zero usage or failure when financial consequences are involved.

Use explicit `UNVERIFIABLE`/degraded states.

## 7. Native sync must become acknowledged and revisioned

Current raw JSON replacement has no conflict/version contract. V2 should introduce:

- commitment/schedule revision;
- last mutation timestamp/source;
- native applied revision;
- conflict policy;
- retry/repair behavior.

## 8. Permission state is product state

Accessibility, Usage Access, overlay, exact alarm, and relevant battery/OEM conditions must be observable and explainable in product UI, especially during financial commitments.

## 9. Migrate compatibility deliberately

Do not delete legacy vote maps, schedule fields, old parsers, or compatibility paths until existing data/readers have been inventoried and migrated.

## 10. Keep production and test/admin surfaces distinct

God Mode, mock Tribunals, score adjustment, and operational bypasses must be build-gated, claim-gated, or moved out of ordinary production navigation.

## 11. Documentation is part of implementation

Changes to product semantics must update `product/`. Changes to technical authority/contracts must update `architecture/`. Verified implementation changes update `engineering/status.md`.
