# System Overview

## Status

This document distinguishes the **audited current repository** from the **target Revoke 2.0 product architecture**.

The source-verified baseline is `../audits/2026-09-04-revival-audit.md`.

## Current architecture

Revoke is an Android-first Flutter application with a native Kotlin enforcement core.

### Flutter currently owns

- Firebase authentication;
- onboarding;
- schedule/regime UI;
- taper setup;
- settings;
- Insights presentation;
- Squads/Tribunals/Pleas;
- notification routing;
- approved-Plea listener that applies native temporary unlocks.

### Kotlin currently owns

- Accessibility foreground events;
- UsageStats fallback/backstop;
- schedule evaluation;
- native overlays;
- temporary unlock persistence;
- local schedule cache;
- alarms;
- boot/restart/watchdog recovery;
- UsageStats-derived usage calculation.

### Firebase currently owns

- Auth;
- Firestore user/squad/regime/Plea data;
- FCM notifications;
- callable/triggered Cloud Functions;
- server-authoritative Plea/vote/message resolution;
- AI Tribunal fallback;
- rap sheets and blocked-attempt server events.

## Current major technical fault lines

From the September 2026 revival audit:

- onboarding/resume and vow persistence are broken;
- Accessibility is foreground-event truth while UsageStats remains usage-budget truth;
- schedule sync has no revision/conflict protocol;
- approved Plea unlock delivery depends on Flutter availability;
- Launch Count is modeled but not enforced;
- Focus Score remains partly client-authoritative;
- taper plan remote hydration is incomplete;
- Firestore same-squad user reads expose more profile data than needed;
- device-level enforcement/recovery tests are missing.

## Rebuild position

Do not rebuild the system wholesale.

Preserve and harden:

- `RevokeAccessibilityService`;
- `EnforcementEngine`;
- `RevokeConfig` local native cache;
- UsageStats calculators/fallback where useful;
- native overlays;
- boot/alarm/watchdog infrastructure;
- server-owned Tribunal write boundaries;
- local-first schedule behavior;
- existing compatibility migrations until data is proven safe to remove.

## Target v2 layering

### Product layer: Commitment

The canonical v2 user object is a `Commitment`.

Flutter/backend domain logic translates Commitments into enforcement primitives.

### Enforcement layer

Existing Time Block and Usage Limit schedules remain the initial native primitives.

Launch Count is excluded from v2 until complete.

### Evidence layer

V2 needs an explicit evidence/verification model that records:

- measurement source;
- health/confidence state;
- evaluation window;
- relevant permission/service state;
- immutable schedule/Commitment revision.

This is particularly important for financial Stakes.

### Accountability layer

Existing Squads/Pleas/Tribunals evolve toward:

- Accountability Circles;
- granular permissions;
- fixed eligible-voter snapshots;
- durable server-to-native override delivery;
- idempotent resolution side effects.

### Financial layer

Financial Stakes are server-authoritative and isolated from subscription billing.

The native engine never charges money.

The financial layer consumes finalized Commitment evidence and may charge only `FAILED_VERIFIED` outcomes.

### Subscription entitlement layer

A server-validated entitlement determines access to paid digital features. On Android Play distribution, Google Play Billing is the default subscription channel unless an approved alternative applies.

## Required v2 reliability changes before money-backed commitments

Money-backed commitments should not ship until all of the following exist:

1. deterministic onboarding/permission state;
2. immutable Commitment activation snapshot;
3. schedule revision/conflict rules;
4. native schedule sync acknowledgment;
5. explicit usage/verification confidence;
6. timezone/day-boundary rules;
7. durable server finalization;
8. server-authoritative grace/failure evaluation;
9. processor idempotency/webhook handling;
10. auditable reason for every `UNVERIFIABLE` decision.
