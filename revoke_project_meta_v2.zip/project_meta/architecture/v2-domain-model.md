# Revoke 2.0 Domain Model

This is a target model for product/engineering alignment. It is not a claim about current Firestore schema.

## Commitment

Suggested fields:

- `id`
- `ownerUserId`
- `name`
- `type: reduce | protect`
- `status`
- `targetPackages[]`
- `createdAt`
- `activationSnapshotId`
- `startAt`
- `endAt`
- `timezone`
- `baseline`
- `goal`
- `planDefinition`
- `enforcementPolicy`
- `overridePolicy`
- `gracePolicy`
- `financialStakeId?`
- `revision`

## CommitmentActivationSnapshot

Immutable record created when a Commitment becomes active.

Contains every field necessary to prove what the user agreed to:

- target packages;
- measurement criteria;
- dates/timezone;
- taper/checkpoints;
- override behavior;
- grace;
- stake amount/currency;
- verification requirements;
- subscription entitlement required;
- Circle/voter policy;
- app/version/device metadata needed for audit;
- terms version.

## CommitmentCheckpoint

- `commitmentId`
- `index`
- `windowStart`
- `windowEnd`
- `target`
- `actual`
- `evidenceStatus: verified | unverifiable`
- `outcome: pass | fail | void`
- `graceConsumed`
- `evaluationRevision`
- `finalizedAt`

## EnforcementRule

Internal/materialized representation mapping a Commitment to existing native primitives.

Initial v2 types:

- `timeBlock`
- `usageLimit`

Do not expose `launchCount` in v2 until implemented end-to-end.

## VerificationWindow

Tracks whether a checkpoint can be financially evaluated.

Suggested fields:

- `commitmentId`
- `checkpointId`
- `deviceId`
- `requiredSignals[]`
- `signalHealth[]`
- `coveragePercent`
- `clockIntegrityStatus`
- `scheduleRevision`
- `nativeAckRevision`
- `result: sufficient | insufficient`
- `reasonCodes[]`

## AccountabilityCircle

- `id`
- `ownerUserId`
- `name`
- `members[]`

Backend migration may temporarily map this to existing Squad documents.

## CircleMembership

- `circleId`
- `memberUserId`
- `defaultPermissions[]`
- `status`
- `joinedAt`

## CommitmentMemberPermission

Per-commitment override of Circle defaults.

- `commitmentId`
- `memberUserId`
- `permissions[]`

## OverrideRequest

Successor/product-layer abstraction over Plea/Tribunal.

- `id`
- `commitmentId`
- `requesterUserId`
- `requestedMinutes`
- `reasonSanitized`
- `policySnapshot`
- `eligibleVoterIds[]`
- `status`
- `verdictSource: self | circle | ai | timeout`
- `approvedUntil?`
- `idempotencyKey`

## FinancialStake

- `id`
- `commitmentId`
- `amountMinor`
- `currency`
- `provider`
- `paymentAuthorizationRef`
- `termsVersion`
- `status`
- `createdAt`

Never store raw payment credentials.

## CommitmentFinancialOutcome

- `commitmentId`
- `evidenceOutcome: succeeded | failed_verified | unverifiable`
- `chargeState`
- `amountMinor`
- `processorReference?`
- `idempotencyKey`
- `finalizedAt`

## SubscriptionEntitlement

- `userId`
- `provider`
- `productId`
- `status`
- `periodStart`
- `periodEnd`
- `sourceTransactionId`
- `verifiedAt`

Entitlement should be verified server-side rather than trusted from client UI state alone.
