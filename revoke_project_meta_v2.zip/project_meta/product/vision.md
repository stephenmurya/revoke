# Revoke 2.0 Vision

## Product thesis

Revoke exists to solve a specific problem:

> The person who makes a commitment and the person who later wants to break it should not have equal authority.

Most screen-time tools optimize for blocking, timers, or awareness. Revoke is designed around **behavioral commitments** and the systems required to keep them when motivation changes.

## Positioning

**Revoke is a commitment-enforcement and behavioral rehabilitation system for distracting apps.**

It helps users move from current behavior to desired behavior using measurable commitments, progressive reduction, strict protection windows, intentional override friction, optional social accountability, and optional financial stakes.

The Android blocker is the enforcement engine. It is not the product itself.

## Core loop

1. **Observe** — establish what the user is actually doing.
2. **Commit** — define what the user wants to change.
3. **Plan** — choose a reduction path or protected boundary.
4. **Enforce** — protect the commitment when temptation appears.
5. **Override deliberately** — breaking the commitment requires an explicit process.
6. **Learn** — identify adherence, override patterns, slips, and risky periods.
7. **Recover** — a lapse should lead back into the plan, not invalidate all progress.
8. **Adapt** — future plans may be adjusted with explicit user approval.

## Primary product object

The primary object is a **Commitment**.

Schedules, time blocks, usage limits, taper stages, reminders, and native enforcement rules are mechanisms generated from or attached to a Commitment.

A Commitment answers:

- What behavior am I changing?
- Which apps are involved?
- What is my baseline?
- What is my target?
- For how long?
- How is this commitment enforced?
- Who, if anyone, can approve exceptions?
- Is money attached to failure?
- What counts as success, failure, grace, or unverifiable evidence?

## Two commitment modes

### Reduce

Progressively lower usage from a measured baseline to a target.

Example: Instagram from 3h/day to 45m/day over six weeks.

### Protect

Create a hard behavioral boundary.

Examples:

- no TikTok from 09:00–17:00;
- no social media for the next four hours;
- Instagram maximum 30 minutes today;
- no games Monday through Thursday.

## Product principles

### 1. The commitment is explicit

Revoke must not silently redefine the user's target, success criteria, financial exposure, or accountability authority.

### 2. Enforcement is local-first

If Firebase, AI, or the Flutter UI disappears temporarily, previously activated commitments should continue to enforce where Android permits.

### 3. Financial consequences require higher evidence than behavioral consequences

Revoke may block based on its normal enforcement confidence. It must only bill a failed financial commitment when failure is verifiable to a higher standard.

### 4. Uncertainty favors the user

If Revoke cannot confidently verify a financially backed commitment because telemetry, permissions, service health, or platform availability was compromised, the result is **UNVERIFIABLE**, not failed. No failure charge is taken.

### 5. Social accountability is optional

A user can use Revoke alone. Accountability Circles strengthen commitments but never gate basic enforcement.

### 6. Privacy follows permission

Circle members see only the commitment information explicitly granted to them. Membership alone does not expose all usage, identity, or behavioral data.

### 7. Slips are not the same as abandonment

Revoke tracks recovery. A user who exceeds a target and returns to plan is making progress even if the commitment record contains a lapse.

### 8. AI executes policy; it does not own the contract

AI may evaluate an override request or surface behavioral patterns. It cannot silently change targets, financial stakes, grace allowances, or Circle permissions.

## What Revoke 2.0 is not

- a generic productivity timer;
- a social network built around screen-time leaderboards;
- a punishment-first app;
- a gambling product;
- a payment product disguised as digital wellness;
- an AI coach that autonomously changes commitments;
- a complete rebuild of the existing Android enforcement stack.
