# Revoke 2.0 Product Specification

Status: **Canonical product direction; not all items are implemented.**

See `../engineering/status.md` before assuming any v2 behavior exists in the current repository.

## 1. Product model

Revoke 2.0 is organized around **Commitments**.

A commitment may produce one or more existing native schedule primitives, but users should primarily think in terms of a behavioral contract rather than individual schedule records.

### Commitment types

- **Reduce** — progressively lower usage over a defined period.
- **Protect** — enforce a fixed usage cap or protected time window.

### Enforcement stages

Revoke uses three conceptual intervention levels:

1. **Notice** — awareness without blocking.
2. **Resist** — added friction before continued use.
3. **Revoke** — commitment threshold crossed; access is blocked until policy permits an override.

The existing soft reminder, interstitial, and hard blocker architecture should be mapped into these concepts rather than rebuilt merely to change terminology.

## 2. Commitment creation

A user selects one or more target apps and defines the behavioral outcome.

Required commitment fields:

- commitment type;
- target apps/packages;
- start time/date;
- end time/date or duration;
- baseline when relevant;
- target usage/window;
- enforcement mode;
- override policy;
- optional Circle assignments;
- optional financial stake;
- grace/retry policy when applicable;
- verification requirements for financial stakes.

### Reduce example

- apps: Instagram, TikTok;
- baseline: 210 minutes/day;
- target: 60 minutes/day;
- duration: 6 weeks;
- taper strategy: balanced;
- enforcement: Notice → Resist → Revoke;
- override: AI Warden or Circle;
- optional stake: ₦20,000;
- grace: 3 missed checkpoints before final failure.

### Protect examples

- TikTok blocked for the next four hours;
- X blocked during work hours;
- Instagram capped at 30 minutes today;
- games blocked Monday–Thursday.

## 3. Tapering

Tapering is a core product behavior, not an auxiliary Home-screen feature.

The initial v2 taper engine should remain deterministic and explainable. It may generate linear or otherwise explicit staged limits from baseline to goal.

Adaptive suggestions may be introduced later, but a change to an active user's commitment requires user approval.

## 4. Overrides

An override is an explicit request to temporarily break or pause an active commitment.

Supported policy modes:

### Self override

Low-friction commitments may allow the user to:

- wait through a delay;
- state a reason;
- request a bounded duration;
- create an audit entry.

### AI Warden

The AI evaluates a bounded request using approved context such as:

- commitment target;
- requested duration;
- current usage;
- recent override behavior;
- grace/retry state;
- sanitized user reason.

AI decisions must not be random.

### Accountability Circle

One or more trusted people may receive, discuss, and vote on an override request according to granular permissions defined in `accountability.md`.

## 5. Financial stakes

A commitment may optionally carry a monetary consequence.

The user explicitly opts in, selects an amount, agrees to the exact success/failure criteria, and authorizes a supported payment method before the commitment activates.

Financially backed commitments have three terminal evidence outcomes:

- **SUCCEEDED** — criteria satisfied; no failure charge.
- **FAILED_VERIFIED** — criteria failed with sufficient evidence; failure charge may be attempted.
- **UNVERIFIABLE** — Revoke cannot establish a trustworthy result; no failure charge.

A financial commitment must never convert uncertainty into a charge.

See `monetization.md` and `commitments.md`.

## 6. Grace and retries

Grace exists to avoid brittle all-or-nothing commitment design.

A commitment may define a limited grace budget before activation. The system must show remaining grace clearly.

For multi-checkpoint commitments such as a six-week taper, a missed verifiable checkpoint may consume grace rather than immediately trigger final failure. Exact taper success policy remains configurable/product-defined but cannot be changed retroactively after activation.

Grace is distinct from telemetry failure. An unverifiable period does **not** consume grace.

## 7. Reliability and verification

Behavioral enforcement and financial verification use different confidence thresholds.

For any financial commitment, Revoke tracks whether the required measurement surface remained trustworthy across the relevant evaluation window.

Possible invalidating conditions include:

- required Android permission unavailable;
- Usage Access unavailable or stale beyond accepted tolerance;
- Accessibility/service health unavailable where required;
- Revoke or enforcement service unavailable for a material portion of the window;
- schedule state conflict that makes the active contract ambiguous;
- server outage that prevents reliable finalization;
- device clock/timezone inconsistency beyond accepted rules;
- any other condition that prevents Revoke from proving failure.

If evidence is insufficient, mark the affected checkpoint or commitment `UNVERIFIABLE` according to policy. No failure charge is taken.

To prevent easy exploitation, a user with broken verification may be temporarily prevented from creating or reinstating new money-backed commitments until health is restored. This restriction is about eligibility for future stakes, not retroactive punishment.

## 8. Homepage

Focus Score is removed from the v2 product model.

Home should surface direct, interpretable cards such as:

- current commitment progress;
- adherence rate;
- overrides requested/approved/denied;
- grace remaining;
- slips and recoveries;
- reduction trend;
- protected windows currently active;
- financial stake status when present;
- verification health when a financial commitment is active.

See `metrics.md`.

## 9. Accountability

Squads evolve into **Accountability Circles** at the product layer.

The existing Squad/Plea/Tribunal backend may be retained internally during migration.

Circle membership is optional. Permissions are granular and may be scoped globally or to specific commitments.

See `accountability.md`.

## 10. Subscription

Revoke 2.0 introduces a paid subscription to fund continued product development, infrastructure, and AI usage.

The paywall should not appear before the user understands their own problem. The preferred onboarding placement is after Revoke has established baseline/goal context and the user has configured a first commitment, but before activating functionality that requires a paid entitlement.

Exact free-tier/trial/pricing decisions remain open in `open-questions.md`.

## 11. Explicitly out of scope for the initial v2 revival

- Launch Count restrictions;
- broad public Social Regimes/community marketplace;
- public leaderboards as a core product loop;
- autonomous AI modification of active commitments;
- payment custody/escrow;
- arbitrary admin verdict overrides;
- rebuilding working native enforcement for stylistic reasons.
