# Revoke 2.0 Onboarding

## Goal

The current onboarding is a release blocker because routing can skip steps and the user's vow/goal is not persisted. The v2 onboarding should be rebuilt as a deterministic state machine with persisted progress, not a fragile page index.

## Design principle

The user should understand their behavior and create a meaningful first Commitment before Revoke asks them to pay.

Permissions should be requested when their purpose is clear, and onboarding must be safely resumable after Android sends the user to system settings.

## Proposed flow

### 1. Welcome

Explain Revoke in one sentence:

> Change the habit, then make the commitment hard to break.

Primary action: start assessment.

### 2. Account

Use the existing Firebase/Google authentication path unless a later product decision moves local-first usage ahead of auth.

Persist onboarding state immediately after authentication.

### 3. Measurement permission

Request Usage Access with a clear explanation that Revoke needs it to establish baseline and evaluate usage-based commitments.

On return, verify actual permission state. Never advance based only on a callback.

### 4. Reality check

Show a short baseline from available usage data:

- total screen time;
- top distracting apps;
- relevant daily averages;
- high-usage periods where reliable.

If insufficient history exists, state that clearly and allow Protect commitments while deferring automatic taper recommendations.

### 5. Choose what to change

Select app(s) and choose:

- **Reduce my usage**; or
- **Protect a period / cap my usage**.

### 6. Define the Commitment

For Reduce:

- baseline;
- target;
- duration;
- taper pace.

For Protect:

- time window or usage cap;
- duration/repeat pattern.

Persist all values immediately.

### 7. Enforcement permissions

Request the remaining Android capabilities required by the selected commitment:

- Accessibility;
- overlay;
- exact alarms where required;
- battery/OEM guidance where relevant.

Each permission step has explicit `required`, `granted`, `denied`, and `return_from_settings` states.

The onboarding state machine must resume at the exact unresolved requirement.

### 8. Enforcement strength

Explain:

- Notice;
- Resist;
- Revoke.

Use sane defaults rather than making users configure every underlying native reminder parameter.

### 9. Override policy

Default solo options:

- self override;
- AI Warden if entitled;
- no override for strict commitments.

Offer **Add an Accountability Circle** as optional. Do not make Circle creation a prerequisite for Home.

If the user adds a Circle, expose granular permission presets and advanced controls.

### 10. Optional financial stake

Offer:

> Put money behind this commitment.

Explain before activation:

- amount;
- exact success criterion;
- grace/retries;
- verification requirement;
- no charge on success;
- charge only on verified failure;
- no charge when Revoke cannot confidently verify the result.

If financial verification prerequisites are not healthy, do not allow stake activation.

### 11. Commitment review

Show one immutable summary:

- apps;
- goal;
- dates;
- enforcement;
- override policy;
- Circle permissions;
- stake amount if any;
- grace;
- billing terms;
- verification state.

The user explicitly confirms the contract.

### 12. Paywall

Preferred placement: after the user has configured and reviewed the first Commitment, but before activating paid functionality.

The paywall must clearly explain which features require subscription, price, billing period, renewal, trial terms if any, and how to cancel.

Exact free/trial entitlement design remains open.

### 13. Activate

Activation should be transactional at the product level:

1. validate required permissions;
2. validate subscription entitlement where required;
3. validate payment authorization if a stake exists;
4. persist immutable Commitment activation snapshot;
5. materialize native schedules;
6. receive native sync acknowledgment;
7. create server state;
8. mark Commitment ACTIVE only when the activation contract is coherent.

If activation fails partway, do not present the commitment as active.

## Onboarding persistence

Persist a semantic state, for example:

- `ACCOUNT_COMPLETE`
- `USAGE_PERMISSION_REQUIRED`
- `BASELINE_COMPLETE`
- `COMMITMENT_DRAFTED`
- `ENFORCEMENT_PERMISSIONS_REQUIRED`
- `OVERRIDE_POLICY_COMPLETE`
- `STAKE_SETUP_COMPLETE`
- `PAYWALL_REQUIRED`
- `READY_TO_ACTIVATE`
- `COMPLETE`

Do not persist only a numeric page index.
