# Metrics and Home Cards

## Focus Score retirement

Revoke 2.0 removes **Focus Score** as a primary product metric.

Reasons:

- a single opaque score hides the behaviors users actually need to understand;
- the current score is partly client-authoritative;
- the onboarding goal that should feed it is currently not persisted;
- Revoke should measure commitment adherence, not generic low screen time.

Legacy Focus Score data may remain during migration but should not shape the v2 information architecture.

## Homepage goal

Home answers:

> Am I keeping the commitments I made, and where am I struggling?

Recommended cards:

### Current Commitment

- target;
- allowance/window;
- current usage;
- time remaining;
- taper stage;
- next checkpoint.

### Adherence

Examples:

- 5 of 6 verifiable commitments kept this week;
- 86% of verifiable checkpoints met;
- current streak only if streaks are useful and non-distorting.

### Override Behavior

- requests this week;
- approved;
- denied;
- self overrides;
- average requested minutes;
- change versus previous period.

### Grace

- remaining grace credits/days;
- when they were consumed;
- whether current commitment is still financially eligible.

### Slips and Recovery

A slip is a verified miss.

Recovery measures how quickly the user returns to plan afterward.

Examples:

- exceeded target yesterday by 32 minutes;
- back within plan today;
- 3 of 4 slips followed by next-checkpoint recovery.

### Reduction Progress

For taper programs:

- baseline;
- current stage target;
- actual recent average;
- final goal;
- change since baseline.

### Danger Zones

Future/advanced analysis may surface periods correlated with overruns or override requests.

Example:

- most overruns happen 22:00–00:30;
- Friday night risk is 2.1× your weekday baseline.

Do not present this as causal certainty.

### Verification Health

Mandatory when a financial stake is active.

Examples:

- Verified — commitment can be financially evaluated.
- Degraded — measurement issue detected; Revoke is attempting recovery.
- Unverifiable — financial consequence disabled for this evaluation.

## Metric semantics

### Adherence rate

Denominator should exclude checkpoints declared `UNVERIFIABLE`.

`adherence = verified_passes / verified_checkpoints`

Do not count unavailable telemetry as failure.

### Override rate

Track separately from adherence. An approved override may or may not alter the commitment result depending on the commitment's policy.

### Recovery rate

A candidate definition:

`recovered_slips / slips_with_followup_checkpoint`

This should remain visible and understandable rather than collapsed into an artificial universal score.
