# Monetization

## Overview

Revoke 2.0 introduces two distinct money systems that must never be conflated:

1. **Subscription** — recurring payment for continued access to Revoke's paid digital service.
2. **Commitment Stake** — optional user-authorized financial consequence charged only after a verified failure of a specific commitment.

They have different product semantics, billing flows, risk, and policy requirements.

## 1. Subscription

### Purpose

Subscription revenue funds:

- product development;
- backend infrastructure;
- AI Warden usage;
- notifications/synchronization;
- device/reliability testing;
- ongoing Android compatibility work.

### Product requirement

The subscription must provide sustained recurring value. Revoke should not frame a recurring plan as payment for one isolated commitment.

### Paywall placement

Preferred v2 placement:

1. user completes baseline/Reality Check;
2. user defines a first Commitment;
3. Revoke shows what will happen;
4. paywall appears before activation of paid entitlements.

This lets the user understand the problem and proposed solution before purchase.

### Billing channel

For a Play-distributed Android app, the default subscription implementation should use **Google Play Billing** unless Revoke deliberately enrolls in and qualifies for an applicable alternative-billing program in a market where that program exists.

Current Google Play policy treats subscriptions and app functionality as digital in-app services subject to Play Billing unless an exception/program applies.

### Entitlement model

Exact pricing is not yet locked.

Recommended direction to evaluate:

#### Free/base

- one basic active Protect commitment;
- core local blocking;
- basic adherence card;
- ability to join another user's Accountability Circle;
- limited self override.

#### Revoke Plus / paid

Candidate paid value:

- unlimited active commitments;
- Reduce/taper programs;
- AI Warden;
- advanced behavioral insights/danger-zone analysis;
- advanced Accountability Circle permissions;
- cross-device/cloud continuity where supported;
- financial stakes;
- richer commitment history.

The final entitlement split is an open product decision. Do not implement the provisional split as fact until locked.

## 2. Commitment Stakes

### Concept

A user may voluntarily attach an amount of money to a commitment.

Examples:

- ₦5,000 if I use TikTok during the next four hours;
- ₦10,000 if I exceed 30 minutes of Instagram today;
- ₦25,000 if I fail my six-week social-media taper after the configured grace allowance.

Success means Revoke takes no failure payment.

Verified failure means Revoke may attempt the agreed charge.

Unverifiable means Revoke does not charge.

### The stake is not a long card hold

Long commitments must not rely on holding card authorization for the entire commitment duration. Card authorization windows expire and vary by network/processor.

The implementation should instead use a processor-supported saved payment method/mandate designed for later merchant-initiated or off-session charges, with explicit user consent and a recovery path if later authentication is required.

### Payment-provider abstraction

The domain model should not hard-code one processor.

Potential provider capabilities needed:

- establish reusable payment authorization/mandate;
- verify authorization health;
- charge a specific amount later;
- webhook-confirm final charge state;
- support authentication/challenge recovery;
- idempotency;
- refunds/voids for operational error;
- regional/currency support.

For Nigeria, Paystack documents reusable card/direct-debit authorizations for later charges. Stripe documents SetupIntents/off-session payment methods for markets/accounts where Stripe is available.

### Critical Play Store policy gate

The stake flow is not equivalent to a normal Google Play subscription. Before implementing in-app stake enrollment, Revoke must obtain a clear platform-policy position on whether this conditional failure charge falls outside Play Billing or requires a particular external/alternative billing program.

Do not ship a processor flow that violates Play's rules for directing users to external payment methods.

This is a compliance gate, not a reason to remove Stakes from the product specification.

## 3. Billing on verified failure

Recommended state sequence:

`ACTIVE → EVALUATING → SUCCEEDED | FAILED_VERIFIED | UNVERIFIABLE`

Only `FAILED_VERIFIED` may create a `CHARGE_PENDING` state.

Charge states:

- `NOT_APPLICABLE`
- `CHARGE_PENDING`
- `CHARGE_SUCCEEDED`
- `CHARGE_REQUIRES_ACTION`
- `CHARGE_FAILED`
- `CHARGE_VOIDED`
- `REFUNDED`

The server owns financial finalization.

The native client must never directly decide to charge a card.

## 4. Verification-first billing rules

Before a failure charge, server-side evaluation must establish:

- immutable Commitment terms;
- correct evaluation window;
- sufficient trustworthy telemetry;
- required permissions/health across the window;
- grace allowance exhausted where relevant;
- no unresolved schedule-sync ambiguity;
- idempotent failure event;
- amount/currency exactly equal to the activation snapshot.

If any required condition is ambiguous, resolve to `UNVERIFIABLE` or manual operational review that cannot independently create a charge without objective evidence.

## 5. User trust rules

- no hidden stakes;
- no default opt-in;
- no stake amount changes after activation;
- no retroactive criteria changes;
- no charge on unverifiable data;
- clear receipt and failure evidence;
- explicit grace rules;
- transparent charge status;
- easy access to support/dispute flow;
- no Circle member can increase stake or decide billing outcome;
- financial terms must be separate from subscription renewal terms.

## 6. Failed payment handling

A failed payment does not convert a failed commitment into success.

Recommended behavior:

- commitment remains `FAILED_VERIFIED`;
- financial state becomes `CHARGE_FAILED` or `CHARGE_REQUIRES_ACTION`;
- user is prompted to resolve payment/authentication;
- new financially backed commitments may be disabled until the unresolved obligation is settled or formally voided;
- ordinary non-financial Revoke functionality should not be held hostage to an operational processor failure unless subscription entitlement separately expires.

Exact retry and collections policy remains open.
