# Accountability Circles and Granular Permissions

## Product direction

The current Squad system evolves into **Accountability Circles**.

A Circle is a set of trusted people who may be given narrowly scoped authority over the user's commitments.

A Circle is optional. Revoke must work for solo users.

The existing Squad/Plea/Tribunal implementation may remain as an internal compatibility layer during migration.

## Permission model

Membership alone grants no broad behavioral visibility.

Permissions can be granted:

1. as a member default; and/or
2. specifically for an individual commitment.

Commitment-specific permissions override member defaults.

Recommended permission set:

### Visibility

- `view_commitment_summary` — name/type/goal/status without detailed usage.
- `view_progress` — adherence and checkpoint progress.
- `view_usage_summary` — aggregate usage relevant to the commitment.
- `view_override_history` — prior override requests/outcomes.
- `view_slip_history` — failed checkpoints and recovery status.
- `view_financial_stake_status` — whether a stake exists and its state; exact amount may be separately controlled.
- `view_financial_stake_amount` — exact amount at risk.

### Notifications

- `receive_progress_updates`
- `receive_slip_alerts`
- `receive_override_requests`
- `receive_commitment_failure_alerts`

### Governance

- `vote_on_overrides`
- `participate_in_override_chat`
- `approve_emergency_override` — optional future/high-trust capability; must be explicitly scoped and audited.

### Administration

- `invite_circle_members` — if multi-admin Circles are supported later.
- `manage_member_permissions` — should default to owner-only in v2.

## Suggested presets

The UI may offer presets that expand into granular permissions:

### Observer

Can see selected progress but cannot vote or receive override requests.

### Accountability Partner

Can see progress, receive override requests, chat, and vote.

### Guardian

High-trust preset with broad commitment visibility and override governance.

Presets are convenience only. The underlying permissions remain explicit and editable.

## Data minimization

Circle members should not automatically receive:

- email address;
- FCM token;
- raw device telemetry;
- complete installed-app list;
- unrelated commitments;
- precise screen-time data outside granted commitments;
- payment credentials;
- processor identifiers.

This directly addresses the current audit finding that same-squad Firestore reads expose broader user-document fields than the product needs.

## Override governance

Each Commitment chooses an override policy.

Possible initial policies:

- self only;
- AI Warden;
- Circle vote;
- AI fallback after Circle timeout;
- no override during a protected window.

For Circle voting, eligibility should be snapshotted when the override request opens. The current participant-based quorum can change dynamically and should not remain the long-term authority model.

Recommended override record includes:

- commitment id;
- requester;
- requested duration;
- sanitized reason;
- eligible voters snapshot;
- votes;
- chat;
- deadline;
- AI fallback policy;
- final verdict source;
- temporary unlock expiry;
- idempotency key.

## Financial commitments and Circle permissions

Circle members must never be able to increase a user's monetary stake or redefine the success criteria of an active commitment.

A Circle may be allowed to:

- see that a financial stake exists;
- see the exact amount only if granted;
- vote on temporary overrides if the commitment policy allows;
- see verified success/failure outcomes.

Circle votes should not directly decide whether a user is billed. Billing follows the immutable commitment criteria and verified telemetry, not social opinion.
