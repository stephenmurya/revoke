# Commitments

## Purpose

A Commitment is the canonical user-facing contract in Revoke 2.0.

Schedules remain useful native enforcement primitives, but users should not need to reason about Revoke as a collection of unrelated schedules.

## Commitment modes

### Reduce

Use when the target behavior is excessive usage rather than total abstinence.

Core fields:

- target apps;
- measured baseline;
- target daily/weekly usage;
- duration;
- taper stages/checkpoints;
- start date;
- enforcement progression;
- override policy;
- optional grace budget;
- optional financial stake.

### Protect

Use when the desired behavior is a fixed boundary.

Subtypes currently map cleanly onto existing implementation primitives:

- **Time protection** → Time Block schedule;
- **Usage cap** → Usage Limit schedule.

Launch Count is not part of the v2 commitment model until it has a complete end-to-end implementation.

## Commitment lifecycle

Recommended state model:

`DRAFT → READY → ACTIVE → COMPLETED`

with terminal or exceptional states:

- `SUCCEEDED`
- `FAILED_VERIFIED`
- `UNVERIFIABLE`
- `CANCELLED`
- `EXPIRED`

For non-financial commitments, `FAILED_VERIFIED` can be treated simply as a recorded failed commitment. The stricter terminology matters primarily when a charge could occur.

## Checkpoints

Long commitments should be evaluated through immutable checkpoints.

Examples:

- one-day usage cap: one checkpoint;
- four-hour protection window: one checkpoint;
- six-week taper: daily or otherwise explicitly defined checkpoints plus a final program result.

Every checkpoint records:

- planned target;
- evaluation window;
- measured result;
- verification status;
- whether grace was consumed;
- outcome;
- source/revision used for evaluation.

## Grace

Grace is chosen before activation.

A grace allowance allows a limited number of verified misses without causing the commitment's final failure.

Rules:

- grace is transparent and visible;
- grace cannot be increased after the first failure without explicitly creating a new/revised commitment;
- unverifiable checkpoints never consume grace;
- deleting/recreating a commitment must not erase a finalized financial obligation;
- grace consumption is server-authoritative for financially backed commitments.

## Financial verification states

Every financially backed evaluation has one of three evidence states:

### Verified pass

Measurement is sufficiently complete and the criterion was met.

### Verified fail

Measurement is sufficiently complete and the criterion was not met.

### Unverifiable

The product cannot establish a trustworthy pass/fail result.

Unverifiable always resolves financially in the user's favor: no failure charge.

## Reinstatement after unverifiable state

When a commitment becomes unverifiable, Revoke should explain why and offer:

- reinstate from now using the original remaining duration;
- select a new start time;
- convert to a non-financial commitment;
- cancel.

A reinstatement is a new evaluation window with a new immutable activation record. Revoke must not retroactively pretend the unverifiable period was measured.

## Tamper and reliability distinction

Revoke should record service/permission health and may classify why evidence was lost, but it should not charge merely because a user appears to have caused the loss of telemetry.

If verification breaks, charge eligibility is lost for that evaluation.

However, Revoke may mark the account/device temporarily ineligible to create another financially backed commitment until required health checks are restored. This removes the obvious force-stop escape exploit without billing from uncertain evidence.

## Commitment editing

Before activation: fully editable.

After activation:

- cosmetic name changes may be allowed;
- target apps, amount, success criteria, grace, duration, and financial terms are immutable;
- loosening or changing these requires closing/replacing the commitment according to explicit rules;
- no retroactive edits to avoid a known failure.

The exact cancellation rules for active financially backed commitments remain a product decision and are listed in `open-questions.md`.
