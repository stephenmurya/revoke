# Open Product Questions

These items are intentionally unresolved. They should not be silently decided in implementation.

## Subscription

1. Is Revoke subscription-only, freemium, or free trial + subscription?
2. What is the exact free entitlement if a free tier exists?
3. Is AI Warden paid-only?
4. Are financial Stakes paid-only?
5. What are monthly/annual prices by market?
6. Where exactly is the paywall placed if a user creates a free-compatible commitment?

## Financial stakes

1. What is the minimum/maximum stake amount by currency/market?
2. How many grace checkpoints are allowed, and can the user choose within a bounded range?
3. For a multi-week taper, what exact rule determines final program success?
4. How much missing telemetry makes a whole multi-week commitment `UNVERIFIABLE` versus voiding only the affected checkpoint?
5. Can a user cancel an active financial commitment? If yes, under what financial consequence, if any?
6. What happens if a card charge requires authentication after verified failure?
7. How many processor retry attempts are appropriate?
8. How are disputes/refunds handled?
9. Which processor(s) and currencies are supported at launch?
10. What Google Play policy path permits the stake enrollment/payment flow in each launch market?

## Accountability

1. Rename `Squad` to `Accountability Circle` everywhere immediately or migrate UI first and backend names later?
2. Exact quorum model for Circle override votes.
3. Should users be able to assign different Circles to different Commitments?
4. Can a Circle member be granted emergency unilateral override authority in v2, or defer?
5. Which granular permission presets ship first?

## Overrides

1. Default maximum override duration.
2. Whether an approved override pauses measurement or counts usage against the commitment.
3. Whether strict Protect commitments can explicitly disable all overrides.
4. AI Warden model/provider and acceptable cost ceiling per subscriber.

## Onboarding

1. Require authentication before baseline or allow local assessment before sign-in?
2. Default commitment suggested from Reality Check.
3. Trial/paywall timing.

## Metrics

1. Exact adherence display period.
2. Whether streaks belong in v2.
3. Exact recovery definition.
4. When Danger Zones are reliable enough to display.
