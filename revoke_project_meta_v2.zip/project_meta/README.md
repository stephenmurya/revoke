# Revoke Project Documentation

This directory is the canonical project knowledge base for **Revoke 2.0**.

The repository historically accumulated PRDs, audits, notes, and status files with overlapping authority. This structure separates **current product truth**, **current technical truth**, **engineering status**, **decision records**, and **historical evidence**.

## Authority order

When documents disagree, use this order:

1. `product/` for current product intent and scope.
2. `architecture/` for current and target technical architecture.
3. `engineering/status.md` for what is actually implemented right now.
4. `decisions/` for why major product/technical choices were made.
5. `audits/` for point-in-time source-verified observations.
6. `archive/` for superseded documentation and historical context.

Audits are evidence, not living specifications. Archived documents are never authoritative for current implementation.

## Current product thesis

Revoke is a **commitment-enforcement and behavioral rehabilitation system** for reducing compulsive use of distracting apps.

The primary product object in v2 is the **Commitment**, not the schedule. Revoke helps a user:

1. observe current behavior;
2. define a behavioral commitment;
3. create a reduction or protection plan;
4. enforce that plan locally on Android;
5. handle override requests deliberately;
6. involve trusted accountability partners when desired;
7. optionally attach a financial stake to a commitment;
8. measure adherence, overrides, slips, and recovery;
9. adapt future plans without silently changing the user's contract.

## Documentation map

### Product

- `product/vision.md` — stable product thesis, principles, and boundaries.
- `product/product-spec.md` — canonical Revoke 2.0 product behavior and scope.
- `product/commitments.md` — commitment model, Reduce/Protect modes, success/failure semantics.
- `product/accountability.md` — Accountability Circles, granular permissions, override governance.
- `product/onboarding.md` — target v2 onboarding and paywall placement.
- `product/monetization.md` — subscription and optional financial-stake model.
- `product/metrics.md` — homepage cards and adherence/recovery measurement; Focus Score retirement.
- `product/open-questions.md` — decisions intentionally not yet locked.

### Architecture

- `architecture/system-overview.md` — audited current architecture and v2 direction.
- `architecture/v2-domain-model.md` — target domain entities and state machines.

### Engineering

- `engineering/status.md` — current implementation reality versus v2 target.
- `engineering/implementation-principles.md` — constraints for reviving rather than rebuilding.

### Decisions

Architectural/Product Decision Records (ADRs/PDRs) for choices that should not be casually reversed.

### Audits

- `audits/2026-09-04-revival-audit.md` — source-verified reconstruction of the current repository.

### Archive

Superseded PRDs, status notes, comparative assessments, and older audits.

## Documentation maintenance rule

Any implementation task that changes user-visible product behavior, persistence authority, enforcement semantics, billing semantics, or backend authority must update the relevant canonical document in the same change. Do not create a new top-level `.md` note when an existing canonical document owns the topic.
