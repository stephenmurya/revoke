# 005 — Introduce Subscription and Paywall

Status: **Accepted**

## Decision

Revoke 2.0 introduces a recurring paid subscription to support product development, infrastructure, and AI costs.

The user should understand their baseline and configure a first Commitment before the primary paywall, rather than encountering a paywall before Revoke demonstrates the problem/solution.

Exact free tier, trial, pricing, and entitlement split remain open.

## Platform consequence

For Play-distributed Android digital services, Google Play Billing is the default implementation unless an eligible market/program explicitly permits an alternative.
