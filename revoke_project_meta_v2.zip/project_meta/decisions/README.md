# Decision Records

Decision records capture choices that materially shape Revoke 2.0.

They are intentionally short. The current product specification contains the full behavior.

Status values:

- **Accepted** — current direction.
- **Superseded** — kept for history but replaced by another decision.
- **Proposed** — not yet locked.

Do not create a new decision record for small implementation details. Use one when reversing the choice later would materially change product behavior, data contracts, or architecture.
