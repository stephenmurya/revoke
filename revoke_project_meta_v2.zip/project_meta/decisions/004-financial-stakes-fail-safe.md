# 004 — Financial Stakes Bill Only Verified Failure

Status: **Accepted**

## Decision

Users may optionally attach money to a Commitment.

Financial evaluation has three outcomes:

- `SUCCEEDED`
- `FAILED_VERIFIED`
- `UNVERIFIABLE`

Only `FAILED_VERIFIED` may trigger a charge.

If Revoke cannot confidently verify usage because required telemetry, permissions, service health, synchronization, or clock integrity is insufficient, the user is not charged.

## Abuse/reliability consequence

Loss of verification may temporarily make the device/account ineligible to start another financial Commitment until health is restored. It does not justify charging the uncertain commitment.

## Payment approach

Do not use long-lived authorization holds for multi-week commitments. Use processor-supported reusable payment authorization/mandate for later charging, subject to platform/payment policy approval.
