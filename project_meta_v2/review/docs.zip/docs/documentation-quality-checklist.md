# Documentation Quality Checklist

Review date: 2026-09-04

- [x] Canonical source for each major topic is identifiable in `project_meta_v2/README.md`.
- [x] `old_project_meta/` is explicitly historical/reference-only and was not edited.
- [x] No application code, Firebase configuration, Firestore rules, Cloud Functions, dependencies, tests, or build configuration was edited.
- [x] Accepted decisions are consistent across product, architecture, engineering, and decisions.
- [x] Unresolved decisions remain visibly marked in `product/open-questions.md`.
- [x] Implementation reality is separate from intended v2 design through `engineering/status.md` and the dated revival audit.
- [x] Focus Score is not reintroduced as a replacement composite metric.
- [x] Squad terminology is labeled as current/internal migration reality, not the final Circle product model.
- [x] Commitment Credit terminology uses available/locked Credits, Credit holds, and the canonical ledger event names.
- [x] Local provisional settlement and server canonical settlement are distinct.
- [x] Offline positive failure evidence changes local projections and creates a durable pending reconciliation event.
- [x] Reinstall/wipe loss before synchronization is explicitly recorded as an accepted v2 risk.
- [x] The initial evidence reconciliation window is 24 hours and remains server-configurable.
- [x] `UNVERIFIABLE` releases locked Credits, forfeits none, and consumes no grace.
- [x] Purchase disclosure is required before every Credit purchase and must be confirmed every time.
- [x] The disclosure acceptance event includes version, user, timestamp, and purchase flow ID.
- [x] The required case-insensitive terminology scan was run; results and classifications are in `terminology-scan.md`.
