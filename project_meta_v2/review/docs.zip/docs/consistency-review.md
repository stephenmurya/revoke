# Documentation Consistency Review

Review date: 2026-09-04

The non-archive canonical corpus and review packet were re-read after the correction pass. The required case-insensitive terminology scan is recorded in `terminology-scan.md`. Historical archive material and the dated source audit are classified separately and were not rewritten.

## Corrections verified

### Credit vocabulary

Canonical docs now use Commitment Credits, Available Credits, Locked Credits, Credit lock, Credit release, Credit forfeiture, and Commitment backing. Backend examples use `available_credits`, `locked_credits`, `credit_holds`, `CREDIT_PURCHASE`, `CREDIT_LOCK`, `CREDIT_RELEASE`, `CREDIT_FORFEITURE`, `PREMIUM_REDEMPTION`, and `PURCHASE_REVERSAL`. The prohibited legacy vocabulary is absent from current product, architecture, decision, and review language.

### Local versus server settlement

`FAILURE_VERIFIED_LOCAL` is a local provisional state. Positive offline failure evidence immediately changes local Credit projections and writes a durable pending reconciliation event. The server ledger remains the canonical authority and must reconcile the event idempotently after reconnect.

### Accepted reinstall risk

If a user wipes or reinstalls before synchronization, the pending local forfeiture may be lost. This is explicitly accepted for v2. The design does not require continuous connectivity or an adversarial anti-avoidance system.

### Resolution policy

The initial default reconciliation window is 24 hours and remains server-configurable. At the end, sufficient evidence produces `SUCCESS_VERIFIED` or `FAILURE_VERIFIED`; insufficient trustworthy evidence produces `UNVERIFIABLE`, releases locked Credits, forfeits none, and consumes no grace.

### Purchase disclosure

Every Credit purchase requires a fresh disclosure and explicit confirmation before Google Play Billing. The acceptance event records disclosure version, user, timestamp, and purchase flow ID. Existing acceptance records do not suppress future disclosures.

## Previous-document status

Previous canonical-facing terminology has been corrected. No accidental legacy terminology remains in current product, architecture, decisions, or review-packet text. Remaining scan matches are limited to intentionally preserved historical archive material or dated implementation evidence; they are not current product or backend terminology.

## Intentional distinctions

The dated revival audit may describe implementation names and historical product assumptions that v2 retires. That evidence remains unchanged so current code reality is not erased. Engineering status connects that evidence to the target v2 architecture.
