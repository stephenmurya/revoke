# Revoke 2.0 Documentation Review Packet

Review date: 2026-09-04

This directory is a review artifact for the documentation-only Revoke 2.0 update. It is not canonical product documentation. Canonical sources live under ../.. and are indexed by ../../README.md.

## Packet contents

- [Change Summary](change-summary.md): every canonical file created, modified, or intentionally left unchanged.
- [Decision Matrix](decision-matrix.md): decisions encoded in this pass, implementation reality, and migration impact.
- [Consistency Review](consistency-review.md): contradictions checked across the v2 corpus and their resolution.
- [Historical Source Map](historical-source-map.md): mapping from old_project_meta and the revival audit into current v2 documentation.
- [Policy and Compliance Assumptions](policy-compliance-assumptions.md): assumptions requiring external validation.
- [Open Questions](open-questions.md): unresolved questions only; accepted decisions are not reopened.
- [Documentation Quality Checklist](documentation-quality-checklist.md): final structural and scope checks.
- [Terminology Scan](terminology-scan.md): required case-insensitive search results and classification of every remaining match.

## Authority reminder

- old_project_meta/ = historical/reference only.
- project_meta_v2/ = current canonical Revoke 2.0 documentation.
- project_meta_v2/archive/ = retained historical material, not current authority.
- project_meta_v2/audits/ = point-in-time implementation evidence, not product intent.
