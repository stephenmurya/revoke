# Revoke 2.0 Decision Matrix

Review date: 2026-09-04

| Decision | Status | Canonical source | Implemented now? | Migration required? |
|---|---|---|---|---|
| Commitment is the primary product object | ACCEPTED | decisions/001; product/vision.md | No complete Commitment domain; schedules are current primitive | Yes |
| Reduce and Protect are the Commitment forms | ACCEPTED | product/commitments.md; product-spec.md | Partial: taper and Time Block/Usage Limit exist separately | Yes |
| Focus Score is retired | ACCEPTED | decisions/002; product/metrics.md | Legacy UI/storage exists | Yes |
| Accountability Circles are optional and granular | ACCEPTED | decisions/003; product/accountability.md | Squad flows exist; Circle model does not | Yes |
| Commitment Credits use `available_credits`, `locked_credits`, and `credit_holds` | ACCEPTED | decisions/008; architecture/credit-ledger-and-billing.md | No v2 ledger | Yes |
| Canonical ledger events are `CREDIT_PURCHASE`, `CREDIT_LOCK`, `CREDIT_RELEASE`, `CREDIT_FORFEITURE`, `PREMIUM_REDEMPTION`, and `PURCHASE_REVERSAL` | ACCEPTED | decisions/008; decisions/010 | No | Yes |
| Positive offline failure may provisionally forfeit locked Credits locally | ACCEPTED | decisions/004; commitment-verification.md | No | Yes |
| Server ledger remains canonical after local synchronization | ACCEPTED | decisions/004; decisions/008 | No | Yes |
| Reinstall/wipe loss before synchronization is accepted v2 risk | ACCEPTED | decisions/004; commitment-verification.md | No | No additional anti-fraud architecture |
| Evidence reconciliation defaults to 24 hours and remains server-configurable | ACCEPTED | decisions/004; commitment-verification.md | No | Yes |
| `UNVERIFIABLE` releases locked Credits, forfeits none, and consumes no grace | ACCEPTED | decisions/004; product/commitments.md | No | Yes |
| Force-close, uninstall, or monitoring loss alone cannot mean failure | ACCEPTED | decisions/004; commitment-verification.md | No | Yes |
| Purchase disclosure is mandatory before every Credit purchase | ACCEPTED | decisions/011; product/monetization.md | No billing implementation | Yes |
| Premium is prepaid and non-auto-renewing | ACCEPTED | decisions/005; product/monetization.md | No Premium/billing code | Yes |
| 100 Credits = 30 Premium days; 25,920 seconds/Credit | ACCEPTED | decisions/009; monetization.md | No | Yes |
| Google Play policy compatibility is not assumed | ACCEPTED | monetization.md; credit-ledger-and-billing.md | External validation only | Release gate |
| Default grace, eligibility, caps, device policy, Circle quorum, and free tier | OPEN | product/open-questions.md | No | Product decision required |
| Social Regimes/community marketplace | DEFERRED | product-spec.md; engineering/status.md | No integrated path | No unless later revived |
