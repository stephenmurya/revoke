# Documentation Change Summary

Review date: 2026-09-04

This packet records the correction pass over the existing `project_meta_v2/` documents. It changes documentation only. Application code, Firebase configuration, Firestore rules, Cloud Functions, dependencies, tests, and `old_project_meta/` were not edited.

## Correction-pass decisions

| Area | Correction | Canonical sources |
|---|---|---|
| Terminology | Replaced legacy risk/prize vocabulary with Commitment Credits, available/locked Credits, Credit holds, and the canonical ledger event names | decisions/010; architecture/v2-domain-model.md; architecture/credit-ledger-and-billing.md |
| Offline failure | Positive offline failure evidence immediately updates local projections, enters `FAILURE_VERIFIED_LOCAL`, and creates a durable pending forfeiture reconciliation event | decisions/004; architecture/commitment-verification.md |
| Settlement authority | Local settlement is provisional; the synchronized server ledger is canonical and reconciles pending events idempotently | decisions/004; decisions/008; architecture/commitment-verification.md |
| Reinstall risk | Loss of an unsynchronized local pending event after wipe/uninstall/reinstall is explicitly accepted for v2 | decisions/004; architecture/commitment-verification.md |
| Resolution window | Initial server-configurable evidence reconciliation default is 24 hours; insufficient trustworthy evidence becomes `UNVERIFIABLE` with Credit release and no forfeiture or grace consumption | decisions/004; architecture/commitment-verification.md; product/commitments.md |
| Purchase disclosure | A confirmed disclosure is required before every Google Play Credit purchase, with an auditable acceptance event; prior acceptance never suppresses a future disclosure | decisions/011; product/monetization.md; architecture/credit-ledger-and-billing.md |

## Earlier v2 work retained

The correction pass preserves the prior v2 decisions: Commitments are primary; Focus Score is retired; Circles are optional; Premium is prepaid; Launch Count is outside initial scope; and the current implementation remains distinct from the target architecture.

## Files changed in the correction pass

- `architecture/credit-ledger-and-billing.md`
- `product/monetization.md`
- `product/commitments.md`
- `decisions/004-credit-forfeiture-fail-safe.md` (renamed from the legacy filename)
- `decisions/008-commitment-credit-ledger.md`
- `decisions/010-neutral-credit-terminology.md`
- `decisions/011-credit-purchase-disclosure.md`
- review packet files in this directory
